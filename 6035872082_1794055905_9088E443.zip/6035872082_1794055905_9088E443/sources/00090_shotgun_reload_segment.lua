-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.shotgun_reload_segment
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.15 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13515046872", 1, 1, true, 10);
end;