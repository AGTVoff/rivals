-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.minigun_wrappedminigun_equip
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://17247639614", 0.25, 1 + 0.1 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://123443443495942", 0.5, 1.25, true, 10);
end;