-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.handgun_handgun_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.35 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://127707586685295", 1, 1 + 0.2 * math.random(), true, 5);
end;