-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.crossbow_harpooncrossbow_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.78 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13456746131", 0.75, 2, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.25 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13456746075", 1, 1.75, true, 10);
end;