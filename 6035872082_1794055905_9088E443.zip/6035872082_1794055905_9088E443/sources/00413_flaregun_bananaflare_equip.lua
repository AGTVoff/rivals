-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.flaregun_bananaflare_equip
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://13456860578", 1.5, 1.5, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.4 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13456860578", 0.75, 1.5, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.4 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13160326139", 0.5, 1.5, true, 10);
end;