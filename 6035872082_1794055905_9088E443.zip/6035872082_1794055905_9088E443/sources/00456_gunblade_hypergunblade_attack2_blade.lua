-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.gunblade_hypergunblade_attack2_blade
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://77594993345414", 0.875, 1.25 + 0.1 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://82009091681573", 1, 1 + 0.1 * math.random(), true, 5);
end;