-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.grenadelauncher_balloonlauncher_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://17274369233", 0.75, 1 + 0.1 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://17274368912", 0.75, 1 + 0.1 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://17803360572", 1, 1 + 0.2 * math.random(), true, 10);
end;