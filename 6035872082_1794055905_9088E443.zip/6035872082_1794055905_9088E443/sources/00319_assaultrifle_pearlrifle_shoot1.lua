-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.assaultrifle_pearlrifle_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://13087362838", 1, 2.4 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://13087362838", 0.5, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://126250530419268", 0.875, 0.9 + 0.1 * math.random(), true, 10);
end;