-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.gunblade_gunsaw_attack1_blade
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://77594993345414", 0.875, 1.15 + 0.1 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://13682898881", 1, 0.7 + 0.1 * math.random(), true, 10);
end;