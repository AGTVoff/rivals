-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.handgun_handgun_inspect_rare
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.5 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://95907783081847", 2.5, 1, true, 10);
end;