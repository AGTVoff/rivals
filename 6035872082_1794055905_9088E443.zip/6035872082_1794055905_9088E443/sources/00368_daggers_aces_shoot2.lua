-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.daggers_aces_shoot2
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://101759165907297", 1, 1, true, 10);
    p1:CreateSound("rbxassetid://127456921117902", 1, 1, true, 10);
end;