-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.daggers_cookies_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://105255527603121", 0.875, 1.25, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://105255527603121", 0.875, 1.25, true, 10);
end;