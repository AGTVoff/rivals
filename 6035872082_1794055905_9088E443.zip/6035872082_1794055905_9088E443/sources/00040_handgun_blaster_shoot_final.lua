-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.handgun_blaster_shoot_final
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://17803104424", 0.75, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://13158330479", 1, 1, true, 5);
end;