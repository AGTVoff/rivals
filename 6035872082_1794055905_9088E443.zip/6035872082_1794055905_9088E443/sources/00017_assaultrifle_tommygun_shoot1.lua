-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.assaultrifle_tommygun_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://17662574783", 0.5, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://76702341159323", 1, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://123959434665593", 1, 1 + 0.2 * math.random(), true, 5);
end;