-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.distortion_electropunkdistortion_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://126144885809059", 0.5, 1 + 0.1 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://138109667994070", 0.5, 1 + 0.1 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://78079958008757", 1.25, 1 + 0.25 * math.random(), true, 10);
end;