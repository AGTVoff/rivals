-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.energypistols_hyperlaserguns_equip
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://13456860578", 1.25, 1.5, true, 0.5 / p2);
    p1:CreateSound("rbxassetid://130113370", 1, 1, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.5 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13483008798", 1, 2, true, 10);
end;