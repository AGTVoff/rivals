-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.daggers_toaster_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.6 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://122724754588572", 1.25, 1 + 0.2 * math.random(), true, 5);
end;