-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.crossbow_archcrossbow_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 1.15 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://114610550422028", 1, 1 + 0.25 * math.random(), true, 10);
end;