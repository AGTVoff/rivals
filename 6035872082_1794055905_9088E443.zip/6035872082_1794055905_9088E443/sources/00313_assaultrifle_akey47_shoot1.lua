-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.assaultrifle_akey47_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://17662574783", 0.875, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://90757583550672", 0.4, 2 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://110122962237431", 1.25, 1 + 0.1 * math.random(), true, 5);
end;