-- Instance: Players .NebulaHub_049.PlayerScripts.Modules.ViewModels.Minigun.Pumpkin Minigun
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Minigun = require(Players.LocalPlayer.PlayerScripts.Modules.ViewModels.Minigun);
local u1 = setmetatable({}, Minigun);
u1.__index = u1;

function u1.new(...) -- Line: 8
    -- upvalues: Minigun (copy), u1 (copy)
    local v2 = Minigun.new(...);
    local v3 = setmetatable(v2, u1);
    v3:_Init();

    return v3;
end;

function u1._Init(p4) -- Line: 26
end;

return u1;