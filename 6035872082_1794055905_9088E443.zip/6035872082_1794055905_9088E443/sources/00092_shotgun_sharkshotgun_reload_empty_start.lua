-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.shotgun_sharkshotgun_reload_empty_start
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.35 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://93644201634454", 0.75, 1 + 0.1 * math.random(), true, 5);

    if not p1:_AnimationWait(script.Name, p3, 0.55 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13515046872", 1, 1, true, 10);
    p1:CreateSound("rbxassetid://71924311860992", 0.75, 1, true, 10);
end;