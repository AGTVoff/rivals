-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.sniper_campfiresniper_reload_empty
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.65 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13455395017", 1, 2, true, 10);
    p1:CreateSound("rbxassetid://13455395017", 1, 1, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.233 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13455395090", 0.25, 0.75 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.2 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://112852622692949", 0.875, 1.1 + 0.1 * math.random(), true, 5);

    if not p1:_AnimationWait(script.Name, p3, 0.85 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://117184161634687", 0.875, 1 + 0.05 * math.random(), true, 5);

    if not p1:_AnimationWait(script.Name, p3, 0.78 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13455394948", 1, 1, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.25 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13455394948", 1, 2, true, 10);
end;