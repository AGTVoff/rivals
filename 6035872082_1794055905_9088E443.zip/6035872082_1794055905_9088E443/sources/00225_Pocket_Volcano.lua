-- Instance: Players .NebulaHub_049.PlayerScripts.Modules.ViewModels.BaseFlareGun.Pocket Volcano
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local BaseFlareGun = require(Players.LocalPlayer.PlayerScripts.Modules.ViewModels.BaseFlareGun);
local u1 = setmetatable({}, BaseFlareGun);
u1.__index = u1;

function u1.new(...) -- Line: 8
    -- upvalues: BaseFlareGun (copy), u1 (copy)
    local v2 = BaseFlareGun.new(...);
    local v3 = setmetatable(v2, u1);
    v3:_Init();

    return v3;
end;

function u1._Init(p4) -- Line: 26
end;

return u1;