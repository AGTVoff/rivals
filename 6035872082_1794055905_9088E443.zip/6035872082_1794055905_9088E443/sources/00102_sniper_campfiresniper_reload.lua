-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.sniper_campfiresniper_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.5 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://112852622692949", 0.875, 1.1 + 0.1 * math.random(), true, 5);

    if not p1:_AnimationWait(script.Name, p3, 0.92 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://117184161634687", 0.875, 1 + 0.05 * math.random(), true, 5);
end;