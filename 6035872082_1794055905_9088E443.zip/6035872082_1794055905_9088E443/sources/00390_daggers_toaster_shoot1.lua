-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.daggers_toaster_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://88834968924220", 1, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://99788947795556", 1.25, 1 + 0.1 * math.random(), true, 5);
end;