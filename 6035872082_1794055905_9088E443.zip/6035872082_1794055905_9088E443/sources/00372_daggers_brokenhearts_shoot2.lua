-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.daggers_brokenhearts_shoot2
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://76357741438822", 1, 1, true, 10);
    p1:CreateSound("rbxassetid://130725438600072", 0.5, 3, true, 10);
end;