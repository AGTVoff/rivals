-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.paintballgun_snowballgun_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://78027467712109", 1, 1.5 + 0.25 * math.random(), true, 5);
end;