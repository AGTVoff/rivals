-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.shotgun_sharkshotgun_reload_empty_finish2
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.45 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://93644201634454", 0.75, 1 + 0.1 * math.random(), true, 5);

    if not p1:_AnimationWait(script.Name, p3, 0.4 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://93644201634454", 0.25, 0.75 + 0.1 * math.random(), true, 5);
end;