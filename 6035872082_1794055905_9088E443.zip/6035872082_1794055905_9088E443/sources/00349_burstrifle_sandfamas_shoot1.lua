-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.burstrifle_sandfamas_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://17662574783", 0.75, 1.2 + 0.4 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://18764343961", 1.125, 1.4 + 0.4 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://87740786635301", 0.375 + 0.25 * math.random(), 0.9 + 0.4 * math.random(), true, 5);
end;