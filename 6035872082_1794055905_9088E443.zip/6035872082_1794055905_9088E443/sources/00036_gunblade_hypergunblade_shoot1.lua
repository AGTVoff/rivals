-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.gunblade_hypergunblade_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://82156077357708", 0.875, 1 + 0.2 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://121373202237894", 0.875, 1 + 0.2 * math.random(), true, 5);
end;