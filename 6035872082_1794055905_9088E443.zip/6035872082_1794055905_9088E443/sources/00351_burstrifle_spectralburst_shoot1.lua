-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.burstrifle_spectralburst_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://13087362838", 0.875, 1.2 + 0.4 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://124080696816628", 0.375, 3.25 + 0.5 * math.random(), true, 5);
end;