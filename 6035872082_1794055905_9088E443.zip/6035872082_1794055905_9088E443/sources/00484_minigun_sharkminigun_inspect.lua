-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.minigun_sharkminigun_inspect
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.5 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://17247639614", 0.25, 1 + 0.1 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 3.5 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://17247639272", 0.2, 0.9 + 0.1 * math.random(), true, 10);
end;