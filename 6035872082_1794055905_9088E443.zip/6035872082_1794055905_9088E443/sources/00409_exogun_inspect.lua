-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.exogun_inspect
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13158735106", 0.15, 1.5, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 1.8 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13158735106", 0.1, 1.25, true, 10);
end;