-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.permafrost_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://108185335541864", 0.875, 1.25 + 0.25 * math.random(), true, 5);
    p1:CreateSound("rbxassetid://100912632191313", 0.875, 1.5 + 0.25 * math.random(), true, 5);
end;