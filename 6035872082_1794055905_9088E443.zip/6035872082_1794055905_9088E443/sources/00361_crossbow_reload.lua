-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.crossbow_reload
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 0.85 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://13682532502", 0.25, 1.5, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 1.4 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://76155503538875", 0.375, 1.75, true, 10);
end;