-- Instance: ReplicatedStorage .Modules.AnimationLibrary.SoundCallbacks.gunblade_crudegunblade_shoot1
-- Class: ModuleScript
-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    p1:CreateSound("rbxassetid://96886470957330", 0.875, 1 + 0.125 * math.random(), true, 5);
end;